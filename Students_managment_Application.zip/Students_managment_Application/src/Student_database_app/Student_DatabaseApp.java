package Student_database_app;

import java.util.Scanner;

public class Student_DatabaseApp {

	public static void main(String[] args) {
		Student stu1=new Student();
		stu1.enroll();
		stu1.payTuition();
		System.out.println(stu1.toString());
				
		//Ask how many new users we want to add
		System.out.println("Enter number of new students to enroll:");
		Scanner sc=new Scanner(System.in);
		int numofStudents =sc.nextInt();
		Student[]students=new Student[numofStudents-1];
		
		
		//create a no.of new students
		for(int n=0;n<numofStudents;n++) {
			students [n]= new Student();
			students [n] .enroll();
			students [n].payTuition();
		//	System.out.println(students .toString());
		//	System.out.println(students[n].toString());

		}	
		for(int n=0;n<numofStudents;n++) 
		{
			System.out.println(students[n].toString());

		}
	}
}

class Student {
	 private String firstName;
     private String lastName;
     private int gradeYear;
     private String studentID;
     private String courses;
     private int tuitionBalance;
     private int costofCourse=600;
     private static int id=1001;
     
     	
	//constructor : Prompt user to enter studentsname and year 
     public Student()
     {
    	 Scanner sc=new Scanner(System.in);
    	 System.out.println("Enter students first name:");
    	 this.firstName=sc.nextLine();
    	 
    	 System.out.println("Enter students last name:");
    	 this.lastName=sc.nextLine();
    	 
    	 System.out.println(" 1-freshmen\n 2-sophmore\n 3-junior\n 4-senior\nEnter student class level:");
    	 this.gradeYear=sc.nextInt();
    	 
    	 setStudentID();
    	 
    	// System.out.println(firstName +" "+ lastName +" "+ gradeYear +" "+studentID);  	  	 
     }
	//Generate an ID
     private void setStudentID() {
    	 //grade level+ID 
    	 id++;  
    	 this.studentID = gradeYear + "" + id;	 
     }
	
	//Enroll in courses
     public void enroll() {
    	 //Get inside a loop, user hits 0
    	 do {
    	 System.out.println("Enter course to enroll(Q to quit):");
    	 Scanner sc = new Scanner(System.in);
    	  String course = sc.nextLine();
    	  if(!course.equals("Q"))
    	  {
    		  courses =courses + "\n" + course;
    		  tuitionBalance =tuitionBalance + costofCourse;
    		  
    	  }
    	  else 
    	  {
    		//  System.out.println("BREAK!");
    		  break;
    	  }
    	 }while (1 != 0);
    	  System.out.println("ENROLLED IN: " + courses);
    	//  System.out.println("TUITIONBALANCE :" + tuitionBalance );
    	  
    			 
     }
	
	//view balance 
     public void viewBalance()
     {
    	 System.out.println("your balance is :$" +tuitionBalance);
    	 
     }
	//pay tuition
     public void payTuition()
     {
    	 viewBalance();
    	 System.out.println("Enter your payment: $");
    	 Scanner sc=new Scanner(System.in);
    	 int payment=sc.nextInt();
    	 tuitionBalance=tuitionBalance -payment;
    	 System.out.println("Thank you for your payment of $" +payment);
    	 viewBalance();
    	 
     }
	
	//show status
	public String toString() {
		return "Name :" + firstName +" "+lastName +
				"\nGrade Level: "+gradeYear +
		        "\nStudent ID: " +studentID +
				"\nCourses Enrolled:" + courses +
				"\nBalance: $" + tuitionBalance;
		
	}
	
	
}